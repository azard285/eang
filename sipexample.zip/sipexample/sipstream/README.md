sipstream
=====

An OTP application

Build
-----

    $ rebar3 compile
